import {StyleSheet, I18nManager} from 'react-native';

export default StyleSheet.create({
  contaner: {overflow: 'hidden'},
  content: {width: '100%', height: '100%'},
});
