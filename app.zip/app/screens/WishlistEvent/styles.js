import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  contentList: {
    paddingHorizontal: 20,
  },
  loadingContent: {flex: 1, alignItems: 'center', justifyContent: 'center'},
});
